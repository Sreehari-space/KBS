chrome.action.onClicked.addListener(() => chrome.tabs.create({url:chrome.runtime.getURL('tool.html?tool=claimpack')}));
